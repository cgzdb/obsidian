###### 版本：V1.0｜正式版
# TrainTowerDefense development guidance

## Unreal Engine

- This is an Unreal Engine 5.8 C++ project.
- When the Unreal Editor is running, use the `unreal-mcp` server to inspect or modify editor-owned state and assets, including levels, actors, components, Blueprints, materials, widgets, project settings, and automation tests.
- Discover the relevant Unreal toolset before calling a tool. Unreal MCP runs tool calls serially on the game thread, so never issue overlapping Unreal MCP calls.
- Inspect existing assets, classes, naming, folders, and project settings before changing them. Do not infer editor state from source files when an MCP inspection tool is available.
- Prefer Unreal MCP for `.uasset` and `.umap` changes. Never edit binary Unreal assets directly on disk.
- Before destructive asset operations—including deletion, replacement, renaming or moving that may break references, bulk modification, and irreversible conversion—report the exact assets, expected impact, and recovery method, then obtain explicit approval. Use a recoverable workflow when the available tools support one.
- Prefer Blueprint implementation for prototype gameplay. Before adding or modifying C++ for gameplay, explain why Blueprint is insufficient, identify affected classes/assets and rebuild impact, and obtain explicit approval. Approved C++ work must stay within the approved scope.
- Use source edits for approved C++ (`Source/`), configuration (`Config/`), and text-based plugin files. Follow Unreal reflection, module, and naming conventions.
- After C++ changes, build the `TrainTowerDefenseEditor` target. Live Coding can update existing function bodies, but new reflected declarations such as `UCLASS`, `USTRUCT`, `UPROPERTY`, or `UFUNCTION` require a full editor/module rebuild and may require restarting the editor.
- After creating or changing an MCP toolset, run `ModelContextProtocol.RefreshTools` and reconnect if its schema changed.
- Do not expose the Unreal MCP endpoint beyond loopback. It has no authentication.
- This file governs technical operations. The project development guidelines govern authorization and safety boundaries, while the current phase plan defines the permitted task scope. Follow all three; if they conflict or are ambiguous, apply the stricter rule and ask before proceeding.
- File ownership must remain clear: update this file only for durable technical operating rules, the project development guidelines only for durable decision and approval rules, and the phase plan only for current scope, implementation decisions, and milestone acceptance records. Do not duplicate a rule across files unless a short cross-reference is necessary.

## Verification

- For editor or Blueprint work, inspect the resulting asset/actor state through Unreal MCP and run the smallest relevant Unreal automation or editor validation tool.
- For C++ work, compile the `TrainTowerDefenseEditor` target and report compiler errors with the owning source file.
- Report verification status precisely: distinguish inspection, automated validation, successful build, editor/play test, and user milestone acceptance. Never describe unrun checks as passed or treat self-checks as user acceptance.
- If a required check cannot be run, state what was not verified, why, and the remaining risk. Do not claim the task is fully verified.
- Keep generated directories (`Binaries/`, `DerivedDataCache/`, `Intermediate/`, and `Saved/`) out of source changes unless a task explicitly requires generated diagnostics.
